﻿namespace Proiect.Models
{
    public class App
    {
    }
}
